from __future__ import annotations

def run(**kwargs):
    return {'status': 'ok', 'tool': 'stay_points', 'stay_points': [{'id': 1, 'duration_min': 12}]}
